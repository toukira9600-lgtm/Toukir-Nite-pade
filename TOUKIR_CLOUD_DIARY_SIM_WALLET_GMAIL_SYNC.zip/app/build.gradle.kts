plugins {
    id("com.android.application")
    if (file("google-services.json").exists()) {
        id("com.google.gms.google-services")
    }
}
android {
    namespace = "com.toukir.clouddiary"
    compileSdk = 35
    defaultConfig {
        applicationId = "com.toukir.clouddiary"
        minSdk = 23
        targetSdk = 35
        versionCode = 3
        versionName = "3.0"
    }
}
dependencies {
    implementation(platform("com.google.firebase:firebase-bom:33.7.0"))
    implementation("com.google.firebase:firebase-auth")
    implementation("com.google.firebase:firebase-firestore")
    implementation("com.google.firebase:firebase-storage")
    implementation("com.google.android.gms:play-services-auth:21.3.0")
}
