package com.toukir.clouddiary;

import android.app.Activity;
import android.os.Bundle;
import android.content.Intent;
import android.content.SharedPreferences;
import android.net.Uri;
import android.view.View;
import android.widget.*;
import com.google.android.gms.auth.api.signin.*;
import com.google.android.gms.common.api.ApiException;
import com.google.firebase.FirebaseApp;
import com.google.firebase.auth.*;
import com.google.firebase.firestore.*;
import com.google.firebase.storage.FirebaseStorage;
import java.util.*;

public class MainActivity extends Activity {
    private static final int RC_SIGN_IN = 1001, RC_FILE = 1002;
    private LinearLayout root, records;
    private EditText simName, phone, walletType, accountName, accountNumber, noteTitle, noteBody;
    private TextView status;
    private SharedPreferences local;
    private FirebaseAuth auth;
    private FirebaseFirestore db;
    private FirebaseStorage storage;
    private GoogleSignInClient googleClient;
    private boolean cloudReady = false;

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        local = getSharedPreferences("toukir_diary", MODE_PRIVATE);
        ScrollView scroll = new ScrollView(this);
        root = new LinearLayout(this); root.setOrientation(1); root.setPadding(22,24,22,24);
        scroll.addView(root);

        TextView heading = new TextView(this); heading.setText("TOUKIR CLOUD DIARY"); heading.setTextSize(24);
        heading.setTypeface(null, android.graphics.Typeface.BOLD); root.addView(heading);
        status = new TextView(this); status.setText("অফলাইন সংরক্ষণ প্রস্তুত। Cloud চালু করতে Firebase কনফিগারেশন লাগবে।"); root.addView(status);

        Button login = button("Gmail / Google দিয়ে লগইন"); root.addView(login); login.setOnClickListener(v -> login());

        section("SIM তথ্য");
        simName = field("SIM-এর নাম / অপারেটর");
        phone = field("মোবাইল নম্বর");

        section("মোবাইল ব্যাংকিং অ্যাকাউন্ট");
        walletType = field("সেবা: বিকাশ / নগদ / উপায় / রকেট");
        accountName = field("অ্যাকাউন্টের নাম");
        accountNumber = field("অ্যাকাউন্ট নম্বর");

        Button saveRecord = button("SIM ও অ্যাকাউন্ট তথ্য সংরক্ষণ"); root.addView(saveRecord);
        saveRecord.setOnClickListener(v -> saveRecord());

        section("ব্যক্তিগত নোট");
        noteTitle = field("নোটের শিরোনাম");
        noteBody = field("নোটের বিস্তারিত");
        noteBody.setMinLines(3);
        Button saveNote = button("নোট সংরক্ষণ"); root.addView(saveNote); saveNote.setOnClickListener(v -> saveNote());

        section("ডকুমেন্ট");
        Button upload = button("ফোন থেকে ডকুমেন্ট বেছে নিন"); root.addView(upload);
        upload.setOnClickListener(v -> pickDocument());

        Button sync = button("Cloud-এ সিঙ্ক / নতুন ফোন থেকে তথ্য আনুন"); root.addView(sync);
        sync.setOnClickListener(v -> syncAll());

        TextView warning = new TextView(this);
        warning.setText("নিরাপত্তা: বিকাশ/নগদ/উপায়/রকেটের PIN, OTP বা পাসওয়ার্ড সংরক্ষণ করবেন না। শুধু অ্যাকাউন্টের নাম ও নম্বর রাখুন।");
        warning.setPadding(0,12,0,12); root.addView(warning);
        section("এই ফোনে সংরক্ষিত তথ্য"); records = new LinearLayout(this); records.setOrientation(1); root.addView(records);
        setContentView(scroll);
        refresh();

        try {
            FirebaseApp.initializeApp(this);
            auth = FirebaseAuth.getInstance(); db = FirebaseFirestore.getInstance(); storage = FirebaseStorage.getInstance();
            String clientId = getString(R.string.default_web_client_id);
            if (!clientId.startsWith("PASTE_")) {
                GoogleSignInOptions gso = new GoogleSignInOptions.Builder(GoogleSignInOptions.DEFAULT_SIGN_IN)
                    .requestIdToken(clientId).requestEmail().build();
                googleClient = GoogleSignIn.getClient(this, gso); cloudReady = true;
                status.setText("Firebase প্রস্তুত। Google দিয়ে লগইন করুন।");
            }
        } catch (Exception ignored) { }
    }

    private void section(String s) { TextView t = new TextView(this); t.setText(s); t.setTextSize(19); t.setTypeface(null,1); t.setPadding(0,20,0,6); root.addView(t); }
    private EditText field(String hint) { EditText e = new EditText(this); e.setHint(hint); root.addView(e); return e; }
    private Button button(String s) { Button b = new Button(this); b.setText(s); return b; }
    private void login() {
        if (!cloudReady || googleClient == null) { toast("Firebase সেটআপ সম্পূর্ণ করতে README অনুসরণ করুন।"); return; }
        startActivityForResult(googleClient.getSignInIntent(), RC_SIGN_IN);
    }
    @Override protected void onActivityResult(int req, int res, Intent data) {
        super.onActivityResult(req,res,data);
        if (req == RC_SIGN_IN) {
            try {
                GoogleSignInAccount a = GoogleSignIn.getSignedInAccountFromIntent(data).getResult(ApiException.class);
                AuthCredential c = GoogleAuthProvider.getCredential(a.getIdToken(), null);
                auth.signInWithCredential(c).addOnCompleteListener(this, task -> {
                    if(task.isSuccessful()){ status.setText("লগইন: "+auth.getCurrentUser().getEmail()); syncAll(); }
                    else toast("লগইন ব্যর্থ। Firebase সেটিংস পরীক্ষা করুন।");
                });
            } catch(Exception e){ toast("লগইন বাতিল বা ব্যর্থ হয়েছে।"); }
        } else if (req == RC_FILE && res == RESULT_OK && data != null) {
            Uri uri = data.getData(); if (uri != null) uploadDocument(uri);
        }
    }
    private void saveRecord() {
        Map<String,Object> m = new HashMap<>();
        m.put("simName", simName.getText().toString()); m.put("phone", phone.getText().toString());
        m.put("walletType", walletType.getText().toString()); m.put("accountName", accountName.getText().toString());
        m.put("accountNumber", accountNumber.getText().toString()); m.put("updatedAt", System.currentTimeMillis());
        String id = "record_"+System.currentTimeMillis(); local.edit().putString(id, toJsonLine(m)).apply();
        clear(simName,phone,walletType,accountName,accountNumber); refresh(); toast("তথ্য ফোনে সংরক্ষিত হয়েছে");
        if(isLoggedIn()) db.collection("users").document(uid()).collection("records").document(id).set(m);
    }
    private void saveNote() {
        String id="note_"+System.currentTimeMillis(); Map<String,Object> m=new HashMap<>();
        m.put("title",noteTitle.getText().toString()); m.put("body",noteBody.getText().toString()); m.put("updatedAt",System.currentTimeMillis());
        local.edit().putString(id,toJsonLine(m)).apply(); clear(noteTitle,noteBody); refresh(); toast("নোট সংরক্ষিত হয়েছে");
        if(isLoggedIn()) db.collection("users").document(uid()).collection("notes").document(id).set(m);
    }
    private String toJsonLine(Map<String,Object> m) { StringBuilder s=new StringBuilder(); for(String k:m.keySet()) s.append(k).append(": ").append(m.get(k)).append("\\n"); return s.toString(); }
    private void refresh() { records.removeAllViews(); for(Map.Entry<String,?> e:local.getAll().entrySet()){ TextView t=new TextView(this); t.setText(e.getValue().toString()+"────────────"); t.setPadding(0,10,0,10); records.addView(t); } }
    private boolean isLoggedIn(){ return auth!=null && auth.getCurrentUser()!=null; }
    private String uid(){ return auth.getCurrentUser().getUid(); }
    private void syncAll() {
        if(!isLoggedIn()){ toast("আগে Google দিয়ে লগইন করুন"); return; }
        String u=uid();
        pullCollection("records",u); pullCollection("notes",u);
        for(Map.Entry<String,?> e:local.getAll().entrySet()){
            String key=e.getKey(), val=String.valueOf(e.getValue());
            Map<String,Object> m=new HashMap<>(); m.put("content",val); m.put("updatedAt",System.currentTimeMillis());
            String col=key.startsWith("record_")?"records":"notes";
            db.collection("users").document(u).collection(col).document(key).set(m);
        }
        toast("Cloud সিঙ্ক শুরু হয়েছে");
    }
    private void pullCollection(String col,String u) {
        db.collection("users").document(u).collection(col).get().addOnSuccessListener(s -> {
            SharedPreferences.Editor ed=local.edit();
            for(DocumentSnapshot d:s.getDocuments()) {
                String content=d.getString("content");
                if(content!=null) ed.putString(d.getId(),content);
                else ed.putString(d.getId(),d.getData().toString());
            }
            ed.apply(); refresh();
        }).addOnFailureListener(e -> toast("Cloud থেকে তথ্য আনা যায়নি; Firestore Rules দেখুন।"));
    }
    private void pickDocument() {
        Intent i=new Intent(Intent.ACTION_OPEN_DOCUMENT); i.setType("*/*"); i.addCategory(Intent.CATEGORY_OPENABLE);
        startActivityForResult(i,RC_FILE);
    }
    private void uploadDocument(Uri uri) {
        if(!isLoggedIn()){ toast("ডকুমেন্ট Cloud-এ রাখতে আগে Google দিয়ে লগইন করুন"); return; }
        String name=uri.getLastPathSegment(); if(name==null) name="document_"+System.currentTimeMillis();
        String path="users/"+uid()+"/documents/"+System.currentTimeMillis()+"_"+name;
        storage.getReference().child(path).putFile(uri).addOnSuccessListener(task -> {
            Map<String,Object> d=new HashMap<>(); d.put("storagePath",path); d.put("name",name); d.put("uploadedAt",System.currentTimeMillis());
            db.collection("users").document(uid()).collection("documents").add(d);
            toast("ডকুমেন্ট Cloud-এ আপলোড হয়েছে");
        }).addOnFailureListener(e -> toast("আপলোড ব্যর্থ। Firebase Storage চালু আছে কি দেখুন।"));
    }
    private void clear(EditText... es){ for(EditText e:es)e.setText(""); }
    private void toast(String s){ Toast.makeText(this,s,Toast.LENGTH_LONG).show(); }
}
