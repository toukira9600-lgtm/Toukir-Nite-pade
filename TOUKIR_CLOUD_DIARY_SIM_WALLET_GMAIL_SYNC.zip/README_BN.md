# TOUKIR CLOUD DIARY — SIM, Wallet, Notes, Documents + Google Cloud

এই প্রজেক্টে SIM নাম/মোবাইল নম্বর, বিকাশ/নগদ/উপায়/রকেটের অ্যাকাউন্টের নাম ও নম্বর, নোট, ডকুমেন্ট বাছাই/Cloud upload, Google Sign-In এবং Firebase sync-এর প্রাথমিক কোড আছে।

## Firebase সেটআপ আবশ্যক
1. https://console.firebase.google.com এ Google account দিয়ে Firebase project তৈরি করুন।
2. Android app যোগ করুন; package name: `com.toukir.clouddiary`
3. `google-services.json` ডাউনলোড করে `app/` ফোল্ডারে রাখুন।
4. Authentication > Sign-in method > Google Enable করুন।
5. Project settings থেকে OAuth Web client ID নিয়ে `app/src/main/res/values/strings.xml`-এর `default_web_client_id`-তে বসান।
6. Firestore Database তৈরি করুন এবং `firestore.rules.example`-এর rules publish করুন।
7. Storage চালু করুন এবং `storage.rules.example`-এর rules publish করুন।
8. Google sign-in-এর জন্য Android app-এর SHA-1 Firebase project settings-এ যোগ করে নতুন `google-services.json` নিন।

## APK build (ফোন থেকে GitHub Actions)
ZIP Extract করুন। ভেতরের সব ফাইল/ফোল্ডার, `.github`-সহ, GitHub repository root-এ আপলোড করুন। Firebase সেটআপের `google-services.json` `app/`-এ রাখুন (Public repository-তে প্রকাশ করবেন না; Private repository ব্যবহার করুন)। Actions > Build Android APK > Run workflow. সফল হলে Artifacts থেকে APK ZIP ডাউনলোড করে Extract করুন।

## গুরুত্বপূর্ণ
- এই কোডটি starter/prototype; release বা sensitive data ব্যবহারের আগে developer review, testing, conflict resolution, file download UI, deletion, offline queue, encryption ও privacy policy দরকার।
- বন্ধুদের APK শেয়ার করা যাবে; প্রত্যেকে নিজের Google account দিয়ে লগইন করলে UID অনুযায়ী আলাদা ডেটা পাবে।
- বিকাশ/নগদ/উপায়/রকেট PIN, OTP, পাসওয়ার্ড বা কার্ড গোপন তথ্য সংরক্ষণ করবেন না।
- Firebase Storage/Firestore ব্যবহারে Google-এর quota ও billing শর্ত প্রযোজ্য হতে পারে।
