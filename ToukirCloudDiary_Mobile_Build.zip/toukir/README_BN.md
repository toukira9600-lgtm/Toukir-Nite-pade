# TOUKIR CLOUD DIARY — Android starter project

এটি Android Studio-তে খোলার উপযোগী একটি প্রাথমিক প্রজেক্ট। Google লগইন এবং Firestore-এ নোট সংরক্ষণের ভিত্তি যুক্ত আছে। এটি এখনো সম্পূর্ণ উৎপাদন-প্রস্তুত অ্যাপ নয়; সিম ম্যানেজার, ফাইল আপলোড/ডাউনলোড, নোট তালিকা ও PIN vault পরবর্তী উন্নয়নের কাজ।

## APK বানানোর জন্য যা লাগবে

1. কম্পিউটারে Android Studio ইনস্টল করুন।
2. https://console.firebase.google.com এ গিয়ে নতুন Firebase project তৈরি করুন।
3. Android app যোগ করুন। Package name দিন: `com.toukir.clouddiary`
4. Firebase থেকে `google-services.json` ডাউনলোড করে `app/` ফোল্ডারে রাখুন।
5. Firebase Authentication > Sign-in method থেকে Google চালু করুন।
6. Firebase project settings থেকে Web client ID নিয়ে `app/src/main/res/values/strings.xml`-এ `default_web_client_id`-এর জায়গায় বসান।
7. Firestore Database তৈরি করুন। নিরাপত্তার জন্য নিচের rules ব্যবহার করুন।
8. Android Studio-তে প্রজেক্ট খুলে Gradle Sync করুন।
9. Build > Build Bundle(s) / APK(s) > Build APK(s) নির্বাচন করুন।

## Firestore security rules

Firebase Console > Firestore Database > Rules-এ:

```text
rules_version = '2';
service cloud.firestore {
  match /databases/{database}/documents {
    match /users/{userId}/{document=**} {
      allow read, write: if request.auth != null && request.auth.uid == userId;
    }
  }
}
```

## গুরুত্বপূর্ণ নিরাপত্তা

- বিকাশ, নগদ, রকেট বা উপায়ের PIN/OTP/পাসওয়ার্ড এই অ্যাপে বা Firestore-এ রাখবেন না।
- Firebase Storage-এ ফাইল সংরক্ষণের আগে Storage চালু করে ব্যবহারকারীভিত্তিক নিরাপত্তা rules সেট করুন।
- Google/Firebase কনফিগারেশন ছাড়া APK তৈরি বা Google লগইন কাজ করবে না।
- এই starter-এ এখন শুধু Google sign-in এবং cloud note create-এর ভিত্তি আছে; নতুন ফোনে নোট পড়া/সিঙ্ক তালিকা ও ডকুমেন্ট ফাইলের UI এখনো যোগ করতে হবে।
