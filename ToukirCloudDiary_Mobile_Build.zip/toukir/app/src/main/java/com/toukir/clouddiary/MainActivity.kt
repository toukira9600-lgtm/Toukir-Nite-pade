package com.toukir.clouddiary

import android.os.Bundle
import android.view.Gravity
import android.widget.*
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {
    private val prefs by lazy { getSharedPreferences("toukir_diary", MODE_PRIVATE) }
    private lateinit var list: TextView
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(32, 36, 32, 28) }
        root.addView(TextView(this).apply { text = "TOUKIR CLOUD DIARY"; textSize = 24f; setTextColor(0xff193A52.toInt()) })
        root.addView(TextView(this).apply { text = "অফলাইন নোট ও SIM তথ্য ম্যানেজার"; textSize = 14f; setPadding(0, 8, 0, 18) })
        val sim = field("SIM / অপারেটরের নাম")
        val phone = field("মোবাইল নম্বর")
        val wallet = field("সেবা: বিকাশ / নগদ / উপায় / রকেট")
        val account = field("অ্যাকাউন্টের নাম (PIN নয়)")
        val title = field("নোটের শিরোনাম")
        val body = field("বিস্তারিত নোট লিখুন").apply { minLines = 3; gravity = Gravity.TOP }
        listOf(sim, phone, wallet, account, title, body).forEach { root.addView(it) }
        root.addView(Button(this).apply {
            text = "মোবাইলে সংরক্ষণ করুন"
            setOnClickListener {
                val old = prefs.getString("entries", "") ?: ""
                val entry = "SIM: ${sim.text}\nনম্বর: ${phone.text}\nসেবা: ${wallet.text}\nঅ্যাকাউন্ট: ${account.text}\nশিরোনাম: ${title.text}\nনোট: ${body.text}\n--------------------\n"
                prefs.edit().putString("entries", old + entry).apply()
                list.text = prefs.getString("entries", "এখনো কোনো তথ্য সংরক্ষণ করা হয়নি।")
                listOf(sim, phone, wallet, account, title, body).forEach { it.text.clear() }
                Toast.makeText(this@MainActivity, "তথ্য ফোনে সংরক্ষিত হয়েছে", Toast.LENGTH_SHORT).show()
            }
        })
        root.addView(TextView(this).apply { text = "সংরক্ষিত তথ্য"; textSize = 18f; setPadding(0, 22, 0, 8) })
        list = TextView(this).apply { textSize = 14f; setTextIsSelectable(true) }
        root.addView(list)
        root.addView(TextView(this).apply {
            text = "সতর্কতা: বিকাশ/নগদ/উপায়/রকেট PIN, OTP বা পাসওয়ার্ড এখানে লিখবেন না। এই সংস্করণে তথ্য শুধু এই ফোনে থাকে; Gmail ক্লাউড সিঙ্ক এখনো চালু হয়নি।"
            textSize = 12f; setPadding(0, 20, 0, 0)
        })
        list.text = prefs.getString("entries", "এখনো কোনো তথ্য সংরক্ষণ করা হয়নি।")
        setContentView(ScrollView(this).apply { addView(root) })
    }
    private fun field(hintText: String) = EditText(this).apply { hint = hintText; textSize = 15f; singleLine = false }
}
